document.getElementById('higherlower').innerHTML = `
  <h2>Higher or Lower</h2>
  <input type="number" id="higherlower-bet" placeholder="Enter your bet">
  <button onclick="higherLowerStart()">Start Game</button>
  <div id="higherlower-current-card">?</div>
  <button onclick="higherLowerGuess('higher')">Higher</button>
  <button onclick="higherLowerGuess('lower')">Lower</button>
  <div id="higherlower-result"></div>
  <div id="higherlower-score">Streak: 0</div>
`;

let higherLowerCurrentCard = getRandomCard();
let higherLowerStreak = 0;
let higherLowerBet = 0; // Store the initial bet

function higherLowerStart() {
  const bet = parseInt(document.getElementById("higherlower-bet").value);
  if (isNaN(bet) || bet <= 0 || bet > bankroll) {
    alert("Invalid bet amount!");
    return;
  }

  updateBankroll(-bet); // Deduct the bet from the bankroll
  higherLowerBet = bet; // Store the bet amount
  higherLowerCurrentCard = getRandomCard();
  higherLowerStreak = 0;

  updateHigherLowerUI();
  document.getElementById("higherlower-result").innerText = "Game started! Keep guessing!";
}

function getRandomCard() {
  return Math.floor(Math.random() * 13) + 1; // 1 to 13
}

function displayCard(value) {
  const faces = { 1: "A", 11: "J", 12: "Q", 13: "K" };
  return faces[value] || value;
}

function updateHigherLowerUI() {
  document.getElementById("higherlower-current-card").innerText = displayCard(higherLowerCurrentCard);
  document.getElementById("higherlower-score").innerText = `Streak: ${higherLowerStreak}`;
}

function higherLowerGuess(guess) {
  const nextCard = getRandomCard();

  let resultText = `Next card was ${displayCard(nextCard)}. `;

  if (
    (guess === "higher" && nextCard > higherLowerCurrentCard) ||
    (guess === "lower" && nextCard < higherLowerCurrentCard)
  ) {
    higherLowerStreak++;
    resultText += "Correct! Keep going!";

    // Check for rewards
    if (higherLowerStreak === 5) {
      const reward = higherLowerBet * 2; // Double the bet
      updateBankroll(reward);
      resultText += ` You reached a streak of 5! You win $${reward}.`;
    } else if (higherLowerStreak === 10) {
      const reward = higherLowerBet * 5; // Multiply bet by 5
      updateBankroll(reward);
      resultText += ` Amazing! You reached a streak of 10! You win $${reward}!`;
    }
  } else {
    // Wrong guess, reset streak
    resultText += "Wrong! Game over.";
    higherLowerStreak = 0;
  }

  higherLowerCurrentCard = nextCard;
  document.getElementById("higherlower-result").innerText = resultText;
  updateHigherLowerUI();
}

updateHigherLowerUI();