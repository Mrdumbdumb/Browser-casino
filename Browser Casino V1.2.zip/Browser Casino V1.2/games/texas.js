document.getElementById('texas').innerHTML = `
  <h2>Texas Hold'em</h2>
  <input type="number" id="texas-bet" placeholder="Enter your bet">
  <button onclick="startTexasGame()">Start Game</button>
  <button onclick="playerFold()">Fold</button>
  <button onclick="playerCall()">Call</button>
  <button onclick="playerRaise()">Raise</button>
  <div id="texas-player-cards"></div>
  <div id="texas-community-cards"></div>
  <div id="texas-output"></div>
  <div id="texas-ai-cards" class="hidden"></div>
`;

let texasDeck = [];
let texasPlayerHand = [];
let texasAIHand = [];
let texasCommunityCards = [];
let texasPot = 0;
let currentBet = 0;
let gamePhase = 0; // 0 = Flop, 1 = Turn, 2 = River, 3 = Showdown

function startTexasGame() {
  const bet = parseInt(document.getElementById("texas-bet").value);

  if (isNaN(bet) || bet <= 0 || bet > bankroll) {
    alert("Invalid bet amount!");
    return;
  }

  updateBankroll(-bet); // Deduct initial bet from bankroll
  texasPot = bet * 2; // Both player and AI contribute to the pot
  currentBet = bet;

  // Initialize deck, hands, and community cards
  texasDeck = createTexasDeck();
  texasPlayerHand = [dealCard(texasDeck), dealCard(texasDeck)];
  texasAIHand = [dealCard(texasDeck), dealCard(texasDeck)];
  texasCommunityCards = [dealCard(texasDeck), dealCard(texasDeck), dealCard(texasDeck), dealCard(texasDeck), dealCard(texasDeck)];
  gamePhase = 0;

  // Display player's hand and initialize output
  document.getElementById("texas-player-cards").innerText = `Your Cards: ${displayHand(texasPlayerHand)}`;
  document.getElementById("texas-community-cards").innerText = "Community Cards: ";
  document.getElementById("texas-output").innerText = "Game started! Make your move.";
  document.getElementById("texas-ai-cards").classList.add("hidden");
}

function playerFold() {
  document.getElementById("texas-output").innerText = "You folded. AI wins the pot!";
  revealAIHand(); // Show AI's hand
  texasPot = 0; // Reset the pot
}

function playerCall() {
  if (currentBet === 0) {
    document.getElementById("texas-output").innerText = "No bet to call!";
    return;
  }

  updateBankroll(-currentBet); // Match AI's bet
  texasPot += currentBet;

  document.getElementById("texas-output").innerText = "You called. Moving to the next phase...";
  nextPhase();
}

function playerRaise() {
  const raiseAmount = parseInt(document.getElementById("texas-bet").value);

  if (isNaN(raiseAmount) || raiseAmount <= 0 || raiseAmount > bankroll) {
    alert("Invalid raise amount!");
    return;
  }

  updateBankroll(-raiseAmount); // Deduct raise from bankroll
  texasPot += raiseAmount;
  currentBet = raiseAmount;

  document.getElementById("texas-output").innerText = `You raised by $${raiseAmount}. AI's turn...`;
  aiDecision(); // Let AI decide
}

function aiDecision() {
  const aiAction = Math.random();

  if (aiAction < 0.3) {
    // AI Folds
    document.getElementById("texas-output").innerText = "AI folded. You win the pot!";
    updateBankroll(texasPot); // Player wins the pot
    texasPot = 0;
  } else if (aiAction < 0.6) {
    // AI Calls
    texasPot += currentBet;
    document.getElementById("texas-output").innerText = "AI called. Moving to the next phase...";
    nextPhase();
  } else {
    // AI Raises
    const aiRaise = Math.min(currentBet * 2, bankroll / 2); // AI raises by doubling the current bet
    texasPot += aiRaise;
    currentBet = aiRaise;
    document.getElementById("texas-output").innerText = `AI raised by $${aiRaise}. Your turn!`;
  }
}

function nextPhase() {
  if (gamePhase === 0) {
    // Flop: Reveal the first three community cards
    document.getElementById("texas-community-cards").innerText = `Community Cards: ${displayHand(texasCommunityCards.slice(0, 3))}`;
    document.getElementById("texas-output").innerText = "Flop revealed. Make your move.";
    gamePhase++;
  } else if (gamePhase === 1) {
    // Turn: Reveal the fourth community card
    document.getElementById("texas-community-cards").innerText = `Community Cards: ${displayHand(texasCommunityCards.slice(0, 4))}`;
    document.getElementById("texas-output").innerText = "Turn revealed. Make your move.";
    gamePhase++;
  } else if (gamePhase === 2) {
    // River: Reveal the fifth community card
    document.getElementById("texas-community-cards").innerText = `Community Cards: ${displayHand(texasCommunityCards)}`;
    document.getElementById("texas-output").innerText = "River revealed. Make your move.";
    gamePhase++;
  } else {
    // Showdown: Determine the winner
    document.getElementById("texas-output").innerText = "Showdown! Determining the winner...";
    determineWinner();
  }
}

function determineWinner() {
  const winner = Math.random() < 0.5 ? "Player" : "AI";

  if (winner === "Player") {
    document.getElementById("texas-output").innerText = `You win the pot of $${texasPot}!`;
    updateBankroll(texasPot);
  } else {
    document.getElementById("texas-output").innerText = `AI wins the pot of $${texasPot}!`;
  }

  revealAIHand(); // Show AI's hand at the end
  texasPot = 0; // Reset the pot
}

function revealAIHand() {
  document.getElementById("texas-ai-cards").innerText = `AI's Cards: ${displayHand(texasAIHand)}`;
  document.getElementById("texas-ai-cards").classList.remove("hidden");
}

function createTexasDeck() {
  const suits = ["♠", "♥", "♦", "♣"];
  const ranks = ["2", "3", "4", "5", "6", "7", "8", "9", "10", "J", "Q", "K", "A"];
  const deck = [];
  suits.forEach(suit => ranks.forEach(rank => deck.push(`${rank}${suit}`)));
  return shuffleDeck(deck);
}

function shuffleDeck(deck) {
  for (let i = deck.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [deck[i], deck[j]] = [deck[j], deck[i]];
  }
  return deck;
}

function dealCard(deck) {
  return deck.pop();
}

function displayHand(hand) {
  return hand.join(", ");
}

// Bankroll Management
function updateBankroll(amount) {
  bankroll += amount;
  localStorage.setItem('bankroll', bankroll); // Persist bankroll across sessions
  document.getElementById('bankroll-display').innerText = `Bankroll: $${bankroll}`;
}

// Initialize bankroll display
document.addEventListener("DOMContentLoaded", () => {
  updateBankroll(0); // Refresh bankroll display on page load
});